# CSEN1095 Data Engineering

This repository contains material, notebooks, and datasets for the Data Engineering course @ the GUC. Most of the material is taken from public repositories, with links to the sources provided for reference and credit.
